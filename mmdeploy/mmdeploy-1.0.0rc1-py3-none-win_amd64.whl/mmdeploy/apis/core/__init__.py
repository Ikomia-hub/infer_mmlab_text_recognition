# Copyright (c) OpenMMLab. All rights reserved.
from .pipeline_manager import PIPELINE_MANAGER, no_mp

__all__ = ['PIPELINE_MANAGER', 'no_mp']
