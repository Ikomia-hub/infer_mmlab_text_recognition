# Copyright (c) OpenMMLab. All rights reserved.
from .optimize_onnx import optimize_onnx

__all__ = ['optimize_onnx']
