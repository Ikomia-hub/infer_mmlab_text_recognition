# Copyright (c) OpenMMLab. All rights reserved.
from mmdeploy.backend.onnxruntime import is_available

__all__ = ['is_available']
