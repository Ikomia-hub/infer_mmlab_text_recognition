# Copyright (c) OpenMMLab. All rights reserved.
from .classification import Classification

__all__ = ['Classification']
