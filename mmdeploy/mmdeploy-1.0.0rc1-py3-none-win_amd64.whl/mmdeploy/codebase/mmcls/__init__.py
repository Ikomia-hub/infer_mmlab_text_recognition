# Copyright (c) OpenMMLab. All rights reserved.
from .deploy import *  # noqa: F401,F403
