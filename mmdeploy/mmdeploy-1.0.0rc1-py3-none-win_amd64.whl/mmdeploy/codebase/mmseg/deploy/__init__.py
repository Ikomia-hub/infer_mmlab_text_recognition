# Copyright (c) OpenMMLab. All rights reserved.
from .segmentation import Segmentation

__all__ = ['Segmentation']
