# Copyright (c) OpenMMLab. All rights reserved.
from .deploy import MMEditing, SuperResolution

__all__ = ['MMEditing', 'SuperResolution']
