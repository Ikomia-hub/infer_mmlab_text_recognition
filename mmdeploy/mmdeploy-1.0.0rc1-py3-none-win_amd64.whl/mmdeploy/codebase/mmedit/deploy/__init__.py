# Copyright (c) OpenMMLab. All rights reserved.
from mmdeploy.codebase.mmedit.deploy.mmediting import MMEditing
from mmdeploy.codebase.mmedit.deploy.super_resolution import SuperResolution

__all__ = ['MMEditing', 'SuperResolution']
