# Copyright (c) OpenMMLab. All rights reserved.
from . import base_edit_model  # noqa: F401,F403
