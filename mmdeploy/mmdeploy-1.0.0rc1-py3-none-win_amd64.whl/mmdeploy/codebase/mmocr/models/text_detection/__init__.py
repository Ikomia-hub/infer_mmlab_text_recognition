# Copyright (c) OpenMMLab. All rights reserved.
from . import fpn_cat  # noqa: F401,F403
from . import heads  # noqa: F401,F403
from . import single_stage_text_detector  # noqa: F401,F403
