# Copyright (c) OpenMMLab. All rights reserved.
from . import text_detection  # noqa: F401,F403
from . import text_recognition  # noqa: F401,F403
