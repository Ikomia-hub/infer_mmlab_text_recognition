# Copyright (c) OpenMMLab. All rights reserved.
from . import oriented_rpn_head  # noqa: F401, F403
from . import rotated_rtmdet_head  # noqa: F401, F403
