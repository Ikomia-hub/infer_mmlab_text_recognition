# Copyright (c) OpenMMLab. All rights reserved.
from .rotated_detection import MMRotate, RotatedDetection

__all__ = ['MMRotate', 'RotatedDetection']
