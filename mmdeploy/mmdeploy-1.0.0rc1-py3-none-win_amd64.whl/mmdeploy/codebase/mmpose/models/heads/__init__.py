# Copyright (c) OpenMMLab. All rights reserved.
from . import mspn_head

__all__ = ['mspn_head']
