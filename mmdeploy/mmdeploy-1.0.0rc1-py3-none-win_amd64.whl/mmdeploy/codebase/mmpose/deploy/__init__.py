# Copyright (c) OpenMMLab. All rights reserved.
from .pose_detection import MMPose, PoseDetection

__all__ = ['PoseDetection', 'MMPose']
