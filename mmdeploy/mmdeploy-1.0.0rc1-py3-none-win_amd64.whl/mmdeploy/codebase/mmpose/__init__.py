# Copyright (c) OpenMMLab. All rights reserved.
from .deploy import PoseDetection

__all__ = ['PoseDetection']
