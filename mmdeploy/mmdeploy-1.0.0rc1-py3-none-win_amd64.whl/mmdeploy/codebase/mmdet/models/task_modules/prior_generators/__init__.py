# Copyright (c) OpenMMLab. All rights reserved.
from . import anchor  # noqa: F401,F403
from . import point_generator  # noqa: F401,F403
