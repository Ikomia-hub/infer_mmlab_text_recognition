# Copyright (c) OpenMMLab. All rights reserved.

from . import recognizers  # noqa: F401,F403
